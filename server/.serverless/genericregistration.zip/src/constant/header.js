// https://cmp-employee-17532.web.app
http://localhost:5173
exports.headers= {
    'Access-Control-Allow-Origin' : 'https://sage-turtle-copy.web.app',
    'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Credentials' : true,
    'Content-Type': 'application/json'
}